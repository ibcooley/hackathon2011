﻿' NOTE: You can use the "Rename" command on the context menu to change the interface name "IService1" in both code and config file together.
<ServiceContract()>
Public Interface IService1

    <OperationContract()> Function AddUser(ByVal firstName As String, ByVal lastName As String, ByVal email As String, ByVal user As String, ByVal type As Integer) As Boolean
    <OperationContract()> Function GetUser(ByVal user As String) As UserItem

    <OperationContract()> Function AddProject(ByVal title As String) As Boolean
    <OperationContract()> Function GetProject(ByVal title As String) As ProjectItem

    <OperationContract()> Function AddStory(ByVal projectTitle As String, ByVal title As String, ByVal description As String) As Boolean
    <OperationContract()> Function GetStory(ByVal projectTitle As String, ByVal title As String) As StoryItem

    <OperationContract()> Function AddTask(ByVal projectTitle As String, ByVal storyTitle As String, ByVal description As String, ByVal deadline As DateTime) As Boolean
    <OperationContract()> Function GetTask(ByVal projectTitle As String, ByVal storyTitle As String, ByVal description As String) As TaskItem

    <OperationContract()> Function GetFullProjectList() As List(Of ProjectItem)

    <OperationContract()> Function GetStatusList(ByVal user As String) As List(Of StatusListItem)

    <OperationContract()> Function GetStoryList(ByVal project As String) As List(Of StoryItem)

    <OperationContract()> Function GetTaskList(ByVal projectTitle As String, ByVal storyTitle As String) As List(Of TaskItem)

    <OperationContract()> Function ChangeStoryStatus(ByVal projectTitle As String, ByVal storyTitle As String, ByVal newStatus As String) As Boolean
    <OperationContract()> Function ChangeTaskStatus(ByVal projectTitle As String, ByVal storyTitle As String, ByVal taskDescription As String, ByVal newStatus As String) As Boolean

End Interface

' Use a data contract as illustrated in the sample below to add composite types to service operations.

<DataContract()>
Public Class StatusListItem

    <DataMember()> Public Property Description As String
    <DataMember()> Public Property ItemStatus As String
    <DataMember()> Public Property ItemType As String
    <DataMember()> Public Property Deadline As DateTime
    <DataMember()> Public Property LastUpdate As DateTime

End Class

<DataContract()>
Public Class ProjectItem

    <DataMember()> Public Property Title As String
    <DataMember()> Public Property Stories As List(Of StoryItem)

End Class

<DataContract()>
Public Class StoryItem

    <DataMember()> Public Property Title As String
    <DataMember()> Public Property Description As String
    <DataMember()> Public Property Status As String

    <DataMember()> Public Property Tasks As List(Of TaskItem)

End Class

<DataContract()>
Public Class TaskItem

    <DataMember()> Public Property Description As String
    <DataMember()> Public Property Status As String

    <DataMember()> Public Property Deadline As DateTime

    <DataMember()> Public Property Users As List(Of UserItem)

End Class

<DataContract()>
Public Class UserItem

    <DataMember()> Public Property Email As String
    <DataMember()> Public Property First As String
    <DataMember()> Public Property Last As String
    <DataMember()> Public Property User As String
    <DataMember()> Public Property Type As String

End Class