﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "Service1" in code, svc and config file together.
Public Class Service1
    Implements IService1

    Private db As New DBDataContext

    Public Sub New()
    End Sub

    Private Sub Reset()
        If db IsNot Nothing Then db.Dispose()
        db = New DBDataContext
    End Sub

    Function AddUser(ByVal firstName As String, ByVal lastName As String, ByVal email As String, ByVal user As String, ByVal type As Integer) As Boolean Implements IService1.AddUser
        Try
            Dim usr As New User With {.FirstName = firstName, .LastName = lastName, .Email = email, .UserName = user, .UserType = type}
            db.Users.InsertOnSubmit(usr)
            db.SubmitChanges()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Function GetUser(ByVal user As String) As UserItem Implements IService1.GetUser
        Dim usr As User = (From iUser In db.Users Where iUser.UserName = user).FirstOrDefault
        Return New UserItem With {.Email = usr.Email, .First = usr.FirstName, .Last = usr.LastName, .Type = If(usr.UserType, "Team Member", "Customer"), .User = usr.UserName}
    End Function

    Public Function GetStatusList(ByVal user As String) As System.Collections.Generic.List(Of StatusListItem) Implements IService1.GetStatusList
        Dim retList As New List(Of StatusListItem)
        Dim usr As User = (From iUser In db.Users Where iUser.UserName = user).FirstOrDefault
        If usr IsNot Nothing Then
            '' 1 means a Team Member; 0 means a customer
            If usr.UserType = 1 Then
                For Each iTaskUser In usr.TaskUsers2s
                    retList.Add(New StatusListItem With {.Description = iTaskUser.Task.Description, .ItemStatus = iTaskUser.Task.TaskStatus.Description, .ItemType = "Task", .Deadline = iTaskUser.Task.Deadline, .LastUpdate = iTaskUser.Task.TimeStamp})
                Next
            End If
            For Each iProjectUser In usr.ProjectUsers
                For Each iStory In iProjectUser.Project.Stories
                    retList.Add(New StatusListItem With {.Description = iStory.Description, .ItemStatus = iStory.StoryStatus.Description, .ItemType = "Story", .LastUpdate = iStory.TimeStamp})
                Next
            Next
        End If
        Return retList

    End Function

    Public Function AddProject(ByVal title As String) As Boolean Implements IService1.AddProject
        Try
            Dim proj As New Project With {.Title = title}
            db.Projects.InsertOnSubmit(proj)
            db.SubmitChanges()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function AddStory(ByVal projectTitle As String, ByVal title As String, ByVal description As String) As Boolean Implements IService1.AddStory
        Try
            Dim proj As Project = (From iProj In db.Projects Where iProj.Title = projectTitle).FirstOrDefault
            If proj IsNot Nothing Then
                Dim story As New Story With {.Title = title, .Description = description, .StoryStatusPrimKey = GetStoryStatus("New").PrimKey}
                db.Stories.InsertOnSubmit(story)
                db.SubmitChanges()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False

    End Function

    Public Function AddTask(ByVal projectTitle As String, ByVal storyTitle As String, ByVal description As String, ByVal deadline As Date) As Boolean Implements IService1.AddTask
        Try
            Dim proj As Project = (From iProj In db.Projects Where iProj.Title = projectTitle).FirstOrDefault
            If proj IsNot Nothing Then
                Dim story As Story = (From iStory In db.Stories Where iStory.ProjectPrimKey = proj.PrimKey AndAlso iStory.Title = storyTitle).FirstOrDefault
                If story IsNot Nothing Then
                    Dim task As New Task With {.StoryPrimKey = story.PrimKey, .Description = description, .Deadline = deadline, .TimeStamp = Now, .TaskStatusPrimKey = GetTaskStatus("Not Started").PrimKey}
                    db.Tasks.InsertOnSubmit(task)
                    db.SubmitChanges()
                    Return True
                End If
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function

    Public Function GetProject(ByVal title As String) As ProjectItem Implements IService1.GetProject
        Dim proj As Project = (From iProj In db.Projects Where iProj.Title = title).FirstOrDefault
        Return New ProjectItem With {.Title = title}
    End Function

    Public Function GetStory(ByVal projectTitle As String, ByVal title As String) As StoryItem Implements IService1.GetStory
        Dim story As Story = (From iStory In db.Stories Where iStory.Project.Title = projectTitle AndAlso iStory.Title = title).FirstOrDefault
        Return New StoryItem With {.Description = story.Description, .Status = story.StoryStatus.Description, .Title = story.Title}
    End Function

    Public Function GetTask(ByVal projectTitle As String, ByVal storyTitle As String, ByVal description As String) As TaskItem Implements IService1.GetTask
        Dim task As Task = (From iTask In db.Tasks Where iTask.Story.Title = storyTitle AndAlso iTask.Story.Project.Title = projectTitle AndAlso iTask.Description = description).FirstOrDefault
        Return New TaskItem With {.Deadline = task.Deadline, .Description = task.Description, .Status = task.TaskStatus.Description}
    End Function

    Private Function GetStoryStatus(ByVal description As String) As StoryStatus
        Dim retVal As StoryStatus = (From iSS In db.StoryStatus Where iSS.Description = description).FirstOrDefault
        If retVal Is Nothing Then
            retVal = New StoryStatus With {.Description = description}
            db.StoryStatus.InsertOnSubmit(retVal)
            db.SubmitChanges()
        End If
        Return retVal
    End Function

    Private Function GetTaskStatus(ByVal description As String) As TaskStatus
        Dim retVal As TaskStatus = (From iTS In db.TaskStatus Where iTS.Description = description).FirstOrDefault
        If retVal Is Nothing Then
            retVal = New TaskStatus With {.Description = description}
            db.TaskStatus.InsertOnSubmit(retVal)
            db.SubmitChanges()
        End If
        Return retVal
    End Function

    Public Function ChangeStoryStatus(ByVal projectTitle As String, ByVal storyTitle As String, ByVal newStatus As String) As Boolean Implements IService1.ChangeStoryStatus
        Dim story As Story = (From iStory In db.Stories Where iStory.Project.Title = projectTitle AndAlso iStory.Title = storyTitle).FirstOrDefault
        If story IsNot Nothing Then
            story.StoryStatus = GetStoryStatus(newStatus)
            db.SubmitChanges()
            Return True
        End If
        Return False
    End Function

    Public Function ChangeTaskStatus(ByVal projectTitle As String, ByVal storyTitle As String, ByVal taskDescription As String, ByVal newStatus As String) As Boolean Implements IService1.ChangeTaskStatus
        Reset()
        Dim task As Task = (From iTask In db.Tasks Where iTask.Story.Title = storyTitle AndAlso iTask.Story.Project.Title = projectTitle AndAlso iTask.Description = taskDescription).FirstOrDefault
        If task IsNot Nothing Then
            task.TaskStatus = GetTaskStatus(newStatus)
            db.SubmitChanges()
            Return True
        End If
        Return False
    End Function

    Public Function GetFullProjectList() As System.Collections.Generic.List(Of ProjectItem) Implements IService1.GetFullProjectList
        Reset()
        Dim retList As New List(Of ProjectItem)
        Dim projects = (From iProject In db.Projects Order By iProject.Title).ToList
        For Each iProject In projects
            Dim projItem As New ProjectItem With {.Title = iProject.Title}
            retList.Add(projItem)
        Next
        Return retList
    End Function

    Public Function GetStoryList(ByVal project As String) As List(Of StoryItem) Implements IService1.GetStoryList
        Reset()
        Dim retList As New List(Of StoryItem)
        Dim stories = (From iStory In db.Stories Where iStory.Project.Title = project Order By iStory.Description).ToList()
        For Each iStory In stories
            Dim storyItem As New StoryItem With {.Description = iStory.Description, .Title = iStory.Title, .Status = iStory.StoryStatus.Description}
            retList.Add(storyItem)
        Next
        Return retList
    End Function

    Public Function GetTaskList(ByVal projectTitle As String, ByVal storyTitle As String) As List(Of TaskItem) Implements IService1.GetTaskList
        Reset()
        Dim retList As New List(Of TaskItem)
        Dim tasks = (From iTask In db.Tasks Where iTask.Story.Title = storyTitle AndAlso iTask.Story.Project.Title = projectTitle).ToList()
        For Each iTask In tasks
            Dim taskitem As New TaskItem With {.Deadline = iTask.Deadline, .Description = iTask.Description, .Status = iTask.TaskStatus.Description, .Users = New List(Of UserItem)}
            retList.Add(taskitem)
            For Each iTaskUser In iTask.TaskUsers2s
                Dim userItem As New UserItem With {.Email = iTaskUser.User.Email, .First = iTaskUser.User.FirstName, .Last = iTaskUser.User.LastName, .Type = If(iTaskUser.User.UserType, "Team Member", "Customer"), .User = iTaskUser.User.UserName}
                taskitem.Users.Add(userItem)
            Next
        Next
        Return retList
    End Function

End Class